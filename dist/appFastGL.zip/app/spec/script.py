from flask import Flask, request, render_template_string, jsonify
import hashlib
import base58
from coincurve import PrivateKey
import threading
import time
import json
import os
import random

app = Flask(__name__)

PROGRESS_FILE = "progress_state.json"
FOUND_KEYS_FILE = "found_keys.txt"

search_thread = None
stop_flag = False
saved_state = None
log_lines = []
search_finished = True

prefix_length = 8  # default prefix length

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>🔍 BTC Key Search</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #1e1e2f;
            color: #e0e0f0;
            padding: 20px;
        }
        h2 {
            text-shadow: 0 0 10px #00ffcc;
        }
        form, button {
            background: #2e2e42;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px #00ffff33;
            margin-bottom: 20px;
        }
        input, select {
            margin: 10px 0;
            padding: 10px;
            border: none;
            border-radius: 5px;
            width: 100%;
            background: #3e3e5e;
            color: #fff;
        }
        button {
            padding: 10px;
            background: #00ffaa;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #00ffcc;
            transform: scale(1.02);
        }
        pre {
            background: #151520;
            padding: 15px;
            border-radius: 10px;
            overflow-y: scroll;
            max-height: 300px;
            box-shadow: inset 0 0 10px #00ffcc44;
        }
        .loader {
            border: 4px solid #333;
            border-top: 4px solid #00ffaa;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-left: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg);}
            100% { transform: rotate(360deg);}
        }
    </style>
</head>
<body>
    <h2>🔍 Bitcoin Key Search</h2>
    <form id="searchForm" method="POST">
        <label>🎯 Target BTC Address:</label>
        <input type="text" name="target_address" required value="{{ target_address }}">
        <label>⏱ Start Key (hex):</label>
        <input type="text" name="start" required pattern="[0-9a-fA-F]{64}" value="{{ start }}">
        <label>🏁 End Key (hex):</label>
        <input type="text" name="end" required pattern="[0-9a-fA-F]{64}" value="{{ end }}">
        <label>🔄 Mode:</label>
        <select name="mode">
            <option value="sequential" {% if mode == "sequential" %}selected{% endif %}>Sequential</option>
            <option value="random" {% if mode == "random" %}selected{% endif %}>Random</option>
        </select>
        <label>🎲 Attempts (random only):</label>
        <input type="number" name="attempts" value="{{ attempts or 1000 }}">
        <label>🔤 Prefix Length:</label>
        <input type="number" name="prefix_length" value="{{ prefix_length or 8 }}" min="1" max="64">
        <button type="submit">🚀 Start Search</button>
    </form>
    <button id="stopBtn" onclick="stopSearch()" disabled>⏸️ Stop</button>
    <button id="resumeBtn" onclick="resumeSearch()" {% if not saved_state_exists %}disabled{% endif %}>▶️ Resume</button>

    <h3>📊 Progress:</h3>
    <pre id="progress">{{ result }}</pre>

    <script>
        let intervalId;
        document.getElementById("searchForm").onsubmit = function(e) {
            e.preventDefault();
            fetch("/", {
                method: "POST",
                body: new FormData(this)
            }).then(res => res.json()).then(data => {
                if(data.error) return alert(data.error);
                document.getElementById("progress").textContent = data.result;
                document.getElementById("stopBtn").disabled = false;
                document.getElementById("resumeBtn").disabled = true;
                intervalId = setInterval(updateProgress, 1000);
            });
        }

        function stopSearch() {
            fetch("/stop").then(() => {
                clearInterval(intervalId);
                document.getElementById("stopBtn").disabled = true;
                document.getElementById("resumeBtn").disabled = false;
            });
        }

        function resumeSearch() {
            fetch("/resume").then(() => {
                intervalId = setInterval(updateProgress, 1000);
                document.getElementById("resumeBtn").disabled = true;
                document.getElementById("stopBtn").disabled = false;
            });
        }

        function updateProgress() {
            fetch("/progress").then(res => res.json()).then(data => {
                document.getElementById("progress").textContent = data.result;
                if(data.finished){
                    clearInterval(intervalId);
                    document.getElementById("stopBtn").disabled = true;
                    document.getElementById("resumeBtn").disabled = true;
                }
            });
        }
    </script>
</body>
</html>
"""

def int_from_hex(s): return int(s, 16)
def hex_from_int(i): return f"{i:064x}"

def pubkey_to_address(pubkey_bytes):
    sha = hashlib.sha256(pubkey_bytes).digest()
    ripemd = hashlib.new('ripemd160', sha).digest()
    prefixed = b'\x00' + ripemd
    chk = hashlib.sha256(hashlib.sha256(prefixed).digest()).digest()[:4]
    return base58.b58encode(prefixed + chk).decode()

def private_key_to_address(priv_hex):
    key_bytes = bytes.fromhex(priv_hex)
    priv = PrivateKey(key_bytes)
    pub = priv.public_key.format(compressed=True)
    return pubkey_to_address(pub)

def log(msg):
    global log_lines
    ts = time.strftime('%H:%M:%S')
    log_lines.append(f"[{ts}] {msg}")
    print(msg)

def save_progress(state):
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(state, f)

def load_progress():
    global saved_state
    try:
        with open(PROGRESS_FILE) as f:
            saved_state = json.load(f)
            return True
    except:
        return False

def remove_progress_file():
    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)

def save_found_key(hex_key, prefix):
    with open(FOUND_KEYS_FILE, "a") as f:
        f.write(f"Prefix: {prefix} | Key: {hex_key}\n")

def search_keys(target_address, start_int, end_int, mode, attempts, prefix_len):
    global stop_flag, log_lines, search_finished
    current = start_int
    checked = 0
    search_finished = False
    log_lines.clear()
    log(f"Search started: {mode} from {hex_from_int(start_int)} to {hex_from_int(end_int)}")

    while current <= end_int:
        if stop_flag:
            # Сохраняем прогресс
            save_progress({
                "current": current,
                "target_address": target_address,
                "end_int": end_int,
                "mode": mode,
                "attempts": attempts,
                "prefix_length": prefix_len
            })
            log("Search stopped by user. Progress saved.")
            search_finished = True
            return

        if mode == "sequential":
            priv_int = current
            current += 1
        elif mode == "random":
            if checked >= attempts:
                break
            priv_int = random.randint(start_int, end_int)
            checked += 1
        else:
            log(f"Unknown mode: {mode}")
            break

        priv_hex = hex_from_int(priv_int)
        addr = private_key_to_address(priv_hex)
        prefix = addr[:prefix_len]

        if prefix == target_address[:prefix_len]:
            log(f"Found matching key! Addr: {addr} Key: {priv_hex}")
            save_found_key(priv_hex, prefix)
            # Здесь можно добавить действия при нахождении ключа, например, остановить поиск
            stop_flag = True
            save_progress({
                "current": priv_int,
                "target_address": target_address,
                "end_int": end_int,
                "mode": mode,
                "attempts": attempts,
                "prefix_length": prefix_len,
                "found": True,
                "found_key": priv_hex,
                "found_address": addr
            })
            search_finished = True
            return

        if checked % 1000 == 0:
            log(f"Checked: {checked if mode=='random' else current - start_int}")

    search_finished = True
    log("Search finished.")

@app.route("/", methods=["GET", "POST"])
def index():
    global search_thread, stop_flag, prefix_length

    if request.method == "POST":
        if search_thread and search_thread.is_alive():
            return jsonify({"error": "Search already in progress."})

        target_address = request.form.get("target_address", "").strip()
        start = request.form.get("start", "").strip()
        end = request.form.get("end", "").strip()
        mode = request.form.get("mode", "sequential")
        attempts = int(request.form.get("attempts", 1000))
        prefix_length = int(request.form.get("prefix_length", 8))

        # Валидация
        if len(start) != 64 or len(end) != 64:
            return jsonify({"error": "Start and End keys must be 64 hex chars."})

        start_int = int_from_hex(start)
        end_int = int_from_hex(end)

        if start_int > end_int:
            return jsonify({"error": "Start must be <= End."})

        stop_flag = False
        log_lines.clear()

        # Запускаем поток поиска
        search_thread = threading.Thread(target=search_keys, args=(target_address, start_int, end_int, mode, attempts, prefix_length))
        search_thread.start()

        return jsonify({"result": "Search started."})

    # GET - рендерим форму
    saved = load_progress()
    context = {
        "target_address": saved_state.get("target_address") if saved else "",
        "start": hex_from_int(saved_state.get("current")) if saved else "",
        "end": hex_from_int(saved_state.get("end_int")) if saved else "",
        "mode": saved_state.get("mode") if saved else "sequential",
        "attempts": saved_state.get("attempts") if saved else 1000,
        "prefix_length": saved_state.get("prefix_length") if saved else 8,
        "result": "\n".join(log_lines),
        "saved_state_exists": saved
    }
    return render_template_string(HTML_TEMPLATE, **context)

@app.route("/stop")
def stop_search():
    global stop_flag
    stop_flag = True
    return jsonify({"result": "Stopping search..."})

@app.route("/resume")
def resume_search():
    global search_thread, stop_flag

    if search_thread and search_thread.is_alive():
        return jsonify({"error": "Search already running."})

    if not load_progress():
        return jsonify({"error": "No saved progress to resume."})

    stop_flag = False
    target_address = saved_state.get("target_address")
    current = saved_state.get("current")
    end_int = saved_state.get("end_int")
    mode = saved_state.get("mode")
    attempts = saved_state.get("attempts")
    prefix_len = saved_state.get("prefix_length")

    search_thread = threading.Thread(target=search_keys, args=(target_address, current, end_int, mode, attempts, prefix_len))
    search_thread.start()
    return jsonify({"result": "Resumed search."})

@app.route("/progress")
def progress():
    global search_finished
    return jsonify({
        "result": "\n".join(log_lines[-50:]),  # последние 50 строк лога
        "finished": search_finished
    })

if __name__ == "__main__":
    app.run(debug=True)
