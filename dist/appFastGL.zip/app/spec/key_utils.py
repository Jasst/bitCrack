import hashlib
import ecdsa
import base58

def private_key_to_wif(priv_key_hex):
    extended_key = "80" + priv_key_hex
    first_sha = hashlib.sha256(bytes.fromhex(extended_key)).digest()
    second_sha = hashlib.sha256(first_sha).digest()
    checksum = second_sha[:4]
    final_key = bytes.fromhex(extended_key) + checksum
    return base58.b58encode(final_key).decode()

def privkey_to_address(priv_key_hex):
    priv_key_bytes = bytes.fromhex(priv_key_hex)
    sk = ecdsa.SigningKey.from_string(priv_key_bytes, curve=ecdsa.SECP256k1)
    vk = sk.verifying_key
    pub_key_bytes = b'\x04' + vk.to_string()
    sha256 = hashlib.sha256(pub_key_bytes).digest()
    ripemd160 = hashlib.new('ripemd160', sha256).digest()
    extended = b'\x00' + ripemd160
    checksum = hashlib.sha256(hashlib.sha256(extended).digest()).digest()[:4]
    address_bytes = extended + checksum
    return base58.b58encode(address_bytes).decode()
