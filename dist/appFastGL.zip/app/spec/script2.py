from flask import Flask, request, render_template_string, jsonify
import hashlib
import base58
from coincurve import PrivateKey
import threading
import time
import json
import os
import random

app = Flask(__name__)

# === GLOBALS ===
PROGRESS_FILE = "progress_state.json"
FOUND_KEYS_FILE = "found_keys.txt"
search_thread = None
stop_flag = False
saved_state = None
log_lines = []
search_finished = True
prefix_length = 8  # default prefix

# === HTML + CSS + JS ===
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>🔍 BTC Key Search</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #1e1e2f;
            color: #e0e0f0;
            padding: 20px;
        }
        h2 {
            text-shadow: 0 0 10px #00ffcc;
        }
        form, button {
            background: #2e2e42;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px #00ffff33;
            margin-bottom: 20px;
        }
        input, select {
            margin: 10px 0;
            padding: 10px;
            border: none;
            border-radius: 5px;
            width: 100%;
            background: #3e3e5e;
            color: #fff;
        }
        button {
            padding: 10px;
            background: #00ffaa;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #00ffcc;
            transform: scale(1.02);
        }
        pre {
            background: #151520;
            padding: 15px;
            border-radius: 10px;
            overflow-y: scroll;
            max-height: 300px;
            box-shadow: inset 0 0 10px #00ffcc44;
        }
        .loader {
            border: 4px solid #333;
            border-top: 4px solid #00ffaa;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-left: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg);}
            100% { transform: rotate(360deg);}
        }
    </style>
</head>
<body>
    <h2>🔍 Bitcoin Key Search</h2>
    <form id="searchForm" method="POST">
        <label>🎯 Target BTC Address:</label>
        <input type="text" name="target_address" required value="{{ target_address }}">
        <label>⏱ Start Key (hex):</label>
        <input type="text" name="start" required pattern="[0-9a-fA-F]{64}" value="{{ start }}">
        <label>🏁 End Key (hex):</label>
        <input type="text" name="end" required pattern="[0-9a-fA-F]{64}" value="{{ end }}">
        <label>🔄 Mode:</label>
        <select name="mode">
            <option value="sequential" {% if mode == "sequential" %}selected{% endif %}>Sequential</option>
            <option value="random" {% if mode == "random" %}selected{% endif %}>Random</option>
        </select>
        <label>🎲 Attempts (random only):</label>
        <input type="number" name="attempts" value="{{ attempts or 1000 }}">
        <label>🔤 Prefix Length:</label>
        <input type="number" name="prefix_length" value="{{ prefix_length or 8 }}" min="1" max="64">
        <button type="submit">🚀 Start Search</button>
    </form>
    <button id="stopBtn" onclick="stopSearch()" disabled>⏸️ Stop</button>
    <button id="resumeBtn" onclick="resumeSearch()" {% if not saved_state_exists %}disabled{% endif %}>▶️ Resume</button>

    <h3>📊 Progress:</h3>
    <pre id="progress">{{ result }}</pre>

    <script>
        let intervalId;
        document.getElementById("searchForm").onsubmit = function(e) {
            e.preventDefault();
            fetch("/", {
                method: "POST",
                body: new FormData(this)
            }).then(res => res.json()).then(data => {
                if(data.error) return alert(data.error);
                document.getElementById("progress").textContent = data.result;
                document.getElementById("stopBtn").disabled = false;
                document.getElementById("resumeBtn").disabled = true;
                intervalId = setInterval(updateProgress, 1000);
            });
        }

        function stopSearch() {
            fetch("/stop").then(() => {
                clearInterval(intervalId);
                document.getElementById("stopBtn").disabled = true;
                document.getElementById("resumeBtn").disabled = false;
            });
        }

        function resumeSearch() {
            fetch("/resume").then(() => {
                intervalId = setInterval(updateProgress, 1000);
                document.getElementById("resumeBtn").disabled = true;
                document.getElementById("stopBtn").disabled = false;
            });
        }

        function updateProgress() {
            fetch("/progress").then(res => res.json()).then(data => {
                document.getElementById("progress").textContent = data.result;
                if(data.finished){
                    clearInterval(intervalId);
                    document.getElementById("stopBtn").disabled = true;
                    document.getElementById("resumeBtn").disabled = true;
                }
            });
        }
    </script>
</body>
</html>
"""

# === UTILITIES ===

def int_from_hex(s): return int(s, 16)
def hex_from_int(i): return f"{i:064x}"

def pubkey_to_address(pubkey_bytes):
    sha = hashlib.sha256(pubkey_bytes).digest()
    ripemd = hashlib.new('ripemd160', sha).digest()
    prefixed = b'\x00' + ripemd
    chk = hashlib.sha256(hashlib.sha256(prefixed).digest()).digest()[:4]
    return base58.b58encode(prefixed + chk).decode()

def private_key_to_address(priv_hex):
    key_bytes = bytes.fromhex(priv_hex)
    priv = PrivateKey(key_bytes)
    pub = priv.public_key.format(compressed=True)
    return pubkey_to_address(pub)

def log(msg):
    global log_lines
    log_lines.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
    print(msg)

def save_progress(state):
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(state, f)

def load_progress():
    global saved_state
    try:
        with open(PROGRESS_FILE) as f:
            saved_state = json.load(f)
            return True
    except:
        return False

def remove_progress_file():
    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)

def save_found_key(hex_key, prefix):
    with open(FOUND_KEYS_FILE, "a") as f:
        f.write(f"Prefix: {prefix} | Key: {hex_key}\n")

def search_keys(target_address, start_int, end_int, mode, attempts, prefix_len):
    global stop_flag, log_lines, search_finished
    current = start_int
    checked = 0
    search_finished = False
    log_lines.clear()
    log(f"Searching from {hex_from_int(start_int)} to {hex_from_int(end_int)}...")

    while current <= end_int:
        if stop_flag:
            save_progress({
                "current": current,
                "target_address": target_address,
                "end_int": end_int,
                "mode": mode,
                "attempts": attempts,
                "prefix_length": prefix_len
            })
            log("🔕 Search paused")
            search_finished = True
            return

        if mode == "random":
            current = random.randint(start_int, end_int)

        priv = hex_from_int(current)
        prefix = priv[:prefix_len]
        try:
            addr = private_key_to_address(priv)
            checked += 1
            if addr == target_address:
                log(f"✅ Match found! {priv}")
                save_found_key(priv, prefix)
                remove_progress_file()
                stop_flag = True
                search_finished = True
                return
        except Exception as e:
            log(f"⚠️ Error: {e}")

        if mode == "sequential":
            current += 1
        if checked % 10000 == 0:
            log(f"Checked: {checked} keys")

    search_finished = True

# === ROUTES ===

@app.route("/", methods=["GET", "POST"])
def index():
    global search_thread, stop_flag, search_finished

    if request.method == "POST":
        data = request.form
        try:
            target = data["target_address"]
            start = int_from_hex(data["start"])
            end = int_from_hex(data["end"])
            mode = data.get("mode", "sequential")
            attempts = int(data.get("attempts", 1000))
            pref_len = int(data.get("prefix_length", 8))
        except Exception as e:
            return jsonify({"error": f"Invalid input: {e}"})

        stop_flag = False
        search_thread = threading.Thread(target=search_keys, args=(target, start, end, mode, attempts, pref_len))
        search_thread.start()
        return jsonify({"result": "🚀 Поиск начался..."})

    load_progress()
    return render_template_string(HTML_TEMPLATE,
        result="\n".join(log_lines[-40:]),
        saved_state_exists=os.path.exists(PROGRESS_FILE),
        target_address="",
        start="0"*64,
        end="f"*64,
        mode="sequential",
        attempts=1000,
        prefix_length=8
    )

@app.route("/progress")
def progress():
    return jsonify({
        "result": "\n".join(log_lines[-50:]),
        "finished": search_finished,
        "saved_state_exists": os.path.exists(PROGRESS_FILE)
    })

@app.route("/stop")
def stop():
    global stop_flag
    stop_flag = True
    return jsonify({"status": "stopped"})

@app.route("/resume")
def resume():
    global search_thread, stop_flag
    if not load_progress(): return jsonify({"error": "No saved progress"})
    stop_flag = False
    st = saved_state
    search_thread = threading.Thread(target=search_keys, args=(
        st["target_address"], st["current"], st["end_int"], st["mode"], st["attempts"], st["prefix_length"]
    ))
    search_thread.start()
    return jsonify({"status": "resumed"})

if __name__ == "__main__":
    app.run(debug=True)
